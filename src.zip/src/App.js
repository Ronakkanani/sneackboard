import './App.css';
import Formik2 from './componet/Formik2';
import Snake from './componet/Snake';

function App() {
  return (
    <>
      {/* <Formik2 /> */}
      <Snake />
    </>
  );
}

export default App;
